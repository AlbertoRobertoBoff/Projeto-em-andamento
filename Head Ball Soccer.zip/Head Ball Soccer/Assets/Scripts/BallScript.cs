﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class BallScript : MonoBehaviour
{
    public Text P1ScoreText;
    public Text P2ScoreText;
    private int p1Score = 0;
    private int p2Score = 0;

    // armazena rigidbody da bolinha
    private Rigidbody2D rb2D;
    //impulso inicial da bola
    public float KickForce;
    // posição inicial da bolinha
    public Transform initialPosition;
    // Start is called before the first frame update
    void Start()
    {
        rb2D = GetComponent<Rigidbody2D>();
        StartCoroutine(SpawnBall());
    }
    IEnumerator SpawnBall()
    {
        transform.position = initialPosition.transform.position;
        rb2D.velocity = Vector2.zero;
        rb2D.isKinematic = true;
        yield return new WaitForSeconds(1.5f);
        rb2D.isKinematic = false;
        float angle = Random.Range(-0.75f, 0.75f);
        Vector2 initialAngle = new Vector2(angle,1);
        rb2D.AddForce(initialAngle * KickForce);         

    }
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if (collision.CompareTag("Goal1"));
        {
            //p2Score++;
            //SetScore(p2Score, P2ScoreText);
            StartCoroutine(SpawnBall());
        }
        if (collision.CompareTag("Goal2"));
        {
            //p1Score++;
            //SetScore(p1Score, P1ScoreText);
            StartCoroutine(SpawnBall());
        }

    }




}
