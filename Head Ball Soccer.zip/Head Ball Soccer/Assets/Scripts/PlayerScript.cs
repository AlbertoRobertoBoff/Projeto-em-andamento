﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerScript : MonoBehaviour
{
    private Rigidbody2D rbd2;
    public Rigidbody2D footRB;

    public float playerMoveSpeed;

    public string horizontalAxisName;
    public string jumpButtonName;
    public string kickButtonName;

    public LayerMask ground;

    public float jumpForce;
    public float kickForce;

    // Start is called before the first frame update
    void Start()
    {
        rbd2 = GetComponent<Rigidbody2D>();  
    }

    // Update is called once per frame
    void Update()
    {

        bool isGrounded = rbd2.IsTouchingLayers(ground);
        if(Input.GetButtonDown(jumpButtonName) && isGrounded)
        {

            rbd2.AddForce(transform.up * jumpForce);

        }

        if(Input.GetButtonDown(kickButtonName))
        {
            footRB.AddTorque(kickForce);
        }
    }
    private void FixedUpdate()
    {
        float h = Input.GetAxis(horizontalAxisName);

        rbd2.velocity = new Vector2(playerMoveSpeed * h, rbd2.velocity.y);
    }
}
